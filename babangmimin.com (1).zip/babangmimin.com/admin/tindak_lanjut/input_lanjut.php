<?php 
include '../../inc/koneksi.php';

$no_skep = $_POST['no_skep'];

$rand = rand();
$ekstensi = array('png','jpg','jpeg','gif','pdf');


//nilai
if(isset($_GET['aksi'])){
	if($_GET['aksi']=='nilai'){

	$file_nilai = $_FILES['up_nilai']['name'];
	$size_nilai = $_FILES['up_nilai']['size'];
	$ext_nilai = pathinfo($file_nilai, PATHINFO_EXTENSION);

	$nilai_per = $_POST['nilai_per'];
	$nilai_pen = $_POST['nilai_pen'];
	$penilai = $_POST['penilai'];
	$ket_nilai = $_POST['ket_nilai'];

		if(!in_array($ext_nilai, $ekstensi)){
			header("location:tindak_lanjut.php?alert=gagal_ekstensi");
		} else {
			if($size_nilai < 1044070){
				$nm = $rand.'_penilaian.'.$ext_nilai;
	  			move_uploaded_file($_FILES['up_nilai']['tmp_name'], '../upload_nilai/'.$nm);
	  			$query = "UPDATE penilaian inner join tindak_lanjut set  penilaian.nilai_perolehan = '$nilai_per', penilaian.hasil_penilaian = '$nilai_pen', penilaian.penilai = '$penilai', penilaian.dok_nilai = '$nm', penilaian.ket_nilai = '$ket_nilai', tindak_lanjut.penilaian = '1', tindak_lanjut.status = 'penilaian' where penilaian.no_skep_bmn = '$no_skep' and tindak_lanjut.no_skep_bmn = '$no_skep'";
				$query_nilai = mysqli_query($con,$query);	
				header("location:tindak_lanjut.php?alert=berhasil");
			} else {
				header("location:tindak_lanjut.php?alert=input_gagal");		
			}
		}
 
	} else {
		//usulan
		if($_GET['aksi']=='usulan'){
			$file_usul = $_FILES['up_usul']['name'];
			$size_usul = $_FILES['up_usul']['size'];
			$ext_usul = pathinfo($file_usul, PATHINFO_EXTENSION);

			$usulan = $_POST['usulan'];
			$no_usulan = $_POST['no_usulan'];
			$tgl_usulan = $_POST['tgl_usulan'];
			$pengajuan = $_POST['tujuan_pengajuan'];
			$nilai = $_POST['nilai_limit'];
			$ket_usulan = $_POST['ket_usulan'];

			if(!in_array($ext_usul, $ekstensi)){
				header("location:tindak_lanjut.php?alert=gagal_ekstensi");
			} else {
				if($size_usul < 1044070){
				$nusul = $rand.'_usulan.'.$ext_usul;
	  			move_uploaded_file($_FILES['up_usul']['tmp_name'], '../upload_peruntukan/'.$nusul);
	  			$query = "UPDATE usulan inner join tindak_lanjut set  usulan.jenis_peruntukan = '$usulan', usulan.no_usulan = '$no_usulan', usulan.tgl_usulan = '$tgl_usulan', usulan.dok_usulan = '$nusul', usulan.tujuan_pengajuan = '$pengajuan', usulan.usulan_limit = '$nilai', usulan.ket_usulan = '$ket_usulan', tindak_lanjut.usulan = '1', tindak_lanjut.status = 'usulan', tindak_lanjut.nilai_limit ='$nilai' where usulan.no_skep_bmn ='$no_skep' and tindak_lanjut.no_skep_bmn = '$no_skep'";
				$query_nilai = mysqli_query($con,$query);	
				header("location:tindak_lanjut.php?alert=berhasil");
				} else {
					header("location:tindak_lanjut.php?alert=input_gagal");	
				}
			}
		}
	}
}



//setuju
if(isset($_GET['aksi'])){
	if($_GET['aksi']=='setuju'){

	$file_setuju = $_FILES['dok_setuju']['name'];
	$size_setuju = $_FILES['dok_setuju']['size'];
	$ext_setuju = pathinfo($file_setuju, PATHINFO_EXTENSION);

	$file_pengajuan = $_FILES['dok_pengajuan']['name'];
	$size_pengajuan = $_FILES['dok_pengajuan']['size'];
	$ext_pengajuan = pathinfo($file_pengajuan, PATHINFO_EXTENSION);

	$setuju = $_POST['setuju'];
	$no_pengajuan = $_POST['no_pengajuan'];
	$tgl_pengajuan = $_POST['tgl_pengajuan'];
	$no_setuju = $_POST['no_setuju'];
	$tgl_setuju = $_POST['tgl_setuju'];
	$bentuk_setuju = $_POST['bentuk_setuju'];
	$ket_setuju = $_POST['ket_setuju'];

		if(!in_array($ext_setuju, $ekstensi)){
			header("location:tindak_lanjut.php?alert=gagal_ekstensi");
		} else {
			if(!in_array($ext_pengajuan, $ekstensi)){
				header("location:tindak_lanjut.php?alert=gagal_ekstensi");
			} else {
				if($size_setuju < 1044070 and $size_pengajuan < 1044070){
				$nm_pengajuan = $rand.'_pengajuan.'.$ext_pengajuan;
	  			move_uploaded_file($_FILES['dok_pengajuan']['tmp_name'], '../upload_peruntukan/'.$nm_pengajuan);

	  			$nm_setuju = $rand.'_persetujuan.'.$ext_setuju;
	  			move_uploaded_file($_FILES['dok_setuju']['tmp_name'], '../upload_peruntukan/'.$nm_setuju);

	  			$query = "UPDATE persetujuan inner join tindak_lanjut set  persetujuan.no_pengajuan = '$no_pengajuan', persetujuan.tgl_pengajuan = '$tgl_pengajuan', persetujuan.dok_pengajuan = '$nm_pengajuan', persetujuan.no_persetujuan = '$no_setuju', persetujuan.tgl_persetujuan = '$tgl_setuju', persetujuan.dok_persetujuan = '$nm_setuju', persetujuan.bentuk_persetujuan = '$bentuk_setuju', persetujuan.ket_persetujuan = '$ket_setuju', tindak_lanjut.persetujuan='1', tindak_lanjut.status='$setuju' where persetujuan.no_skep_bmn = '$no_skep' and tindak_lanjut.no_skep_bmn = '$no_skep'";
				$query_setuju = mysqli_query($con,$query);	
				header("location:tindak_lanjut.php?alert=berhasil");
			} else {
				header("location:tindak_lanjut.php?alert=input_gagal");		
			}
		}
		}

	} else {
		//selesai
		if($_GET['aksi']=='selesai'){
			$file_kegiatan = $_FILES['dok_kegiatan']['name'];
			$size_kegiatan = $_FILES['dok_kegiatan']['size'];
			$ext_kegiatan = pathinfo($file_kegiatan, PATHINFO_EXTENSION);

			$file_selesai = $_FILES['dok_selesai']['name'];
			$size_selesai = $_FILES['dok_selesai']['size'];
			$ext_selesai = pathinfo($file_selesai, PATHINFO_EXTENSION);

			$file_foto = $_FILES['foto_kegiatan']['name'];
			$size_foto = $_FILES['foto_kegiatan']['size'];
			$ext_foto = pathinfo($file_foto, PATHINFO_EXTENSION);

			$selesai = $_POST['selesai'];
			$no_selesai = $_POST['no_selesai'];
			$tgl_selesai = $_POST['tgl_selesai'];
			$no_kegiatan = $_POST['no_kegiatan'];
			$tgl_kegiatan = $_POST['tgl_kegiatan'];
			$waktu_kegiatan = $_POST['waktu_kegiatan'];
			$bentuk_keg = $_POST['bentuk_kegiatan'];


			if(!in_array($ext_kegiatan, $ekstensi) and !in_array($ext_selesai, $ekstensi) and !in_array($ext_foto, $ekstensi)){
				header("location:tindak_lanjut.php?alert=gagal_ekstensi");
			} else {
				if($size_selesai < 1044070 and $size_kegiatan < 1044070 and $size_foto < 1044070){
				$nm_selesai = 'dok_selesai_'.$rand.'.'.$ext_selesai;
	  			move_uploaded_file($_FILES['dok_selesai']['tmp_name'], '../upload_peruntukan/'.$nm_selesai);

	  			$nm_kegiatan = 'kegiatan_'.$rand.'.'.$ext_kegiatan;
	  			move_uploaded_file($_FILES['dok_kegiatan']['tmp_name'], '../upload_peruntukan/'.$nm_kegiatan);

	  			$nm_foto = 'foto_'.$rand.'.'.$ext_foto;
	  			move_uploaded_file($_FILES['foto_kegiatan']['tmp_name'], '../foto_kegiatan/'.$nm_foto);

	  			$query = "UPDATE penyelesaian inner join tindak_lanjut set  penyelesaian.no_pengajuan = '$no_selesai', penyelesaian.tgl_pengajuan = '$tgl_selesai', penyelesaian.dok_pengajuan = '$nm_selesai', penyelesaian.no_kegiatan = '$no_kegiatan', penyelesaian.tgl_kegiatan = '$tgl_kegiatan', penyelesaian.berkas_kegiatan = '$nm_kegiatan', penyelesaian.bentuk_kegiatan = '$bentuk_keg', penyelesaian.waktu_pelaksanaan = '$waktu_kegiatan', penyelesaian.foto_kegiatan = '$nm_foto', tindak_lanjut.penyelesaian = '1', tindak_lanjut.status = '$selesai' where penyelesaian.no_skep_bmn ='$no_skep' and tindak_lanjut.no_skep_bmn = '$no_skep'";
				$query_kegiatan = mysqli_query($con,$query);	
				header("location:tindak_lanjut.php?alert=berhasil");
				} else {
					header("location:tindak_lanjut.php?alert=input_gagal");	
				}
			}
		}
	}
}




if(isset($_GET['aksi'])){
	if($_GET['aksi']=='hapus'){
		$hapus_skep = $_POST['hapus_skep'];
		$hapus_no = $_POST['hapus_no'];
		$hapus_tgl = $_POST['hapus_tgl'];
		$hapus_ket = $_POST['hapus_ket'];

		$file_hapus = $_FILES['hapus_dok']['name'];

		$size_hapus = $_FILES['hapus_dok']['size'];
		$ext_hapus = pathinfo($file_hapus, PATHINFO_EXTENSION);

		if(!in_array($ext_hapus,$ekstensi) ) {
  		header("location:../search/cari.php?alert=gagal_ekstensi");
  	} else {
  		if($size_hapus < 1044070){
  		$hps = $rand.'_hapus.'.$ext_hapus;
  		move_uploaded_file($_FILES['hapus_dok']['tmp_name'], '../upload_hapus/'.$hps);
		$query3 = "INSERT INTO `mohon_hapus`(`id`, `no_skep_bmn`, `no_dokumen`, `berkas_permohonan`, `tgl_hapus`, `keterangan`) VALUES ('','$hapus_skep','$hapus_no','$hps','$hapus_tgl','$hapus_ket')";
		$query_hapus = mysqli_query($con, $query3);

		header("location:../search/cari.php?alert=berhasil");
	} else {
		header("location:../search/cari.php?alert=input_gagal");
	}
}
}
}





?>