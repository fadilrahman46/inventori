<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Barang yang Menjadi Milik Negara</title> <!-- CSS -->
  <link href="../../assets/css/bootstrap.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../assets/fonts/css/all.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/login.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.css">
<script  src="../../assets/js/form.js" type="text/javascript"></script>
</head>
<style>
* {
  box-sizing: border-box;
}

body {
  background-color: #f1f1f1;
}

#regForm {
  background-color: #ffffff;
  margin: 50px auto;
  font-family: Raleway;
  padding: 40px;
  width: 70%;
  min-width: 450px;
}

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #6751b7;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}
</style>

<body>
<?php include '../../inc/cek-login.php'; ?>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="../index.php">Aplikasi Barang yang Menjadi Milik Negara</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
  <a class="btn" style="background-color:white;color:grey;" href="../index.php">Back to Home</a>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i> <?php echo $_SESSION['username'];?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="../pass.php"><i class="fas fa-cog"></i> Ganti Password ..</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </ul>
      </div>
    </div>
  </nav>

<div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
    <div class="card card0 border-0" style="background-color: #6751b7; margin-bottom: 10px;">
        <div class="row d-flex">
            <div class="col-lg-6">
                <div class="card1 pb-5" style="margin-top: 50px;">
                    <div class="row px-3 justify-content-center mb-5 border-line"> <img src="../../icon.png" height="270" width="300" style="border-radius: 5px"> </div>
                    <span class="row px-3 justify-content-center"><a class="btn" style="background-color:#28156f
;color:white;" href="tindak_lanjut.php">Back to Tindak Lanjut</a></span>
                
                </div>
            </div>
            <div class="col-lg-6">
                    <?php 
                    $no_skep = $_GET['no_skep'];
                     //echo $no_skep;
                    ?>
                    <form id="regForm" method="POST" action="input_lanjut.php?aksi=setuju" enctype="multipart/form-data">
  
  <!-- One "tab" for each step in the form: -->
                      <div class="tab form-group" style="margin-bottom: 50px;">
                        <h3>FORM PERSETUJUAN</h3>
                        <input type="hidden" name="no_skep" value="<?php echo $no_skep; ?>">
                        <label>Jenis Peruntukan</label>
                        <p><input name="setuju" value="persetujuan" readonly="readonly"></p>   
                        <label>Nomor Pengajuan</label>
                        <p><input  name="no_pengajuan"></p>
                        <label>Tanggal Pengajuan</label>
                        <p><input type="date" name="tgl_pengajuan"></p>
                        <label>Dokumen Pengajuan</label>
                        <p><input type="file" name="dok_pengajuan"></p>
                      </div>
                      <div class="tab form-group">
                        <h3>FORM PERSETUJUAN</h3>                       
                        <label>Nomor Persetujuan</label>
                        <p><input  name="no_setuju"></p>
                        <label>Tanggal Persetujuan</label>
                        <p><input type="date"  name="tgl_setuju"></p>
                        <label>Dokumen Persetujuan</label>
                        <p><input type="file" name="dok_setuju"></p>
                        <label>Bentuk Persetujuan</label>
                        <p><input  name="bentuk_setuju"></p>
                        <label>Keterangan</label>
                        <p><textarea  name="ket_setuju"></textarea></p>
                      </div>
                  
                      <div style="overflow:auto;">
                        <div style="float:right;">
                          <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                          <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                        </div>
                      </div>
                      <!-- Circles which indicates the steps of the form: -->
                     <div style="text-align:center;margin-top:40px;">
                        <span class="step"></span>
                        <span class="step"></span>
                        
                      </div>
                    </form>
                        <!-- Form -->
                                    
                    
            </div>
            </div>
        </div>
        <div class="bg-blue py-4">
            <div class="row px-3"> <small class="ml-4 ml-sm-5 mb-2">Copyright &copy; 2021. All rights reserved.</small>
                <div class="social-contact ml-4 ml-sm-auto"> <span class="fa fa-facebook mr-4 text-sm"></span> <span class="fa fa-google-plus mr-4 text-sm"></span> <span class="fa fa-linkedin mr-4 text-sm"></span> <span class="fa fa-twitter mr-4 mr-sm-5 text-sm"></span> </div>
            </div>
        </div>
    </div>
</div>

</body>
<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";

  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  //document.getElementById("nextBtn").type = "submit"
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    document.getElementById("nextBtn").type = "submit"
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
</script>
<script  src="../../assets/js/form.js" type="text/javascript"></script>
  <script src="../../assets/js/jquery.slim.js"></script>
  <script src="../../assets/js/bootstrap.bundle.js"></script>
</html>