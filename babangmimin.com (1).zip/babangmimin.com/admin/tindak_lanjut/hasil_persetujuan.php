 <h2>Hasil Pencarian</h2>
  
  <a href="input.php">+ Tambah Barang</a>           
  <table class="table table-striped">
    <thead>
      <tr>
        <th>No</th>
        <th>No.SKEP BMN</th>
        <th>Tgl SKEP BMN</th>
        <th>Dokumen Asal</th>
        <th>Nilai Limit</th>
        <th>Peruntukan</th>
        <th>Status</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php 
  include "../../inc/koneksi.php";
  $query_mysql = mysqli_query($con, "SELECT * FROM tbl_utama")or die(mysqli_error());
      // $kode_barang = 1;
      // $harga_barang = 1;
  while($data = mysqli_fetch_array($query_mysql)){
  ?>
      <tr>
        <td><?php echo $data['no']; ?></td>
        <td><?php echo $data['no_skep_bmn']; ?></td>
        <td><?php echo $data['tgl_skep_bmn']; ?></td>
        <td><?php echo $data['nomor_dokumen']; ?></td>
        <td><?php echo $data['tanggal_dokumen']; ?></td>
        <td><?php echo $data['berkas_permohonan']; ?></td>
        <td><?php echo $data['keterangan']; ?></td>
        <td><a href="edit.php?id=<?php echo $data['id']; ?>"><button type="button" class="btn btn-success">Terima</button></a> <a href="hapus.php?id=<?php echo $data['id']; ?>"><button type="button" class="btn btn-danger">Tolak</button></a></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>