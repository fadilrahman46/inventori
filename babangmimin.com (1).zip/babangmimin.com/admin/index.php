<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Barang yang Menjadi Milik Negara</title> </head>

  <link href="../assets/css/bootstrap.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/fonts/css/all.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/login.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">

</head>

<body>
<?php include '../inc/cek-login.php'; ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
<div class="container">
  <a class="navbar-brand" href="index.php">Aplikasi Barang yang Menjadi Milik Negara</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="navbar-nav ml-auto">
      <!-- <li class="nav-item active">
        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home
          <span class="sr-only">(current)</span>
        </a>
      </li>
    </ul> -->
    <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-user"></i> <?php echo $_SESSION['username'];?>
    </a>
    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
      <a class="dropdown-item" href="pass.php"><i class="fas fa-cog"></i> Ganti Password ..</a>
      <div class="dropdown-divider"></div>
      <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
  </ul>
  </div>
</div>
</nav>




<div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
<?php 
    if(isset($_GET['pesan'])){
      if($_GET['pesan']=='terima'){
        ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-check"></i> Peringatan !</h4>
          Data Berhasil Dihapus
        </div>                
        <?php
      }elseif($_GET['pesan']=="tolak"){
        ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-warning"></i> Peringatan !</h4>
          Penghapusan Data Ditolak
        </div>                
        <?php
      }
    }
    ?>

    <div class="card card0 border-0" style="background-color: #6751b7">
        <div class="row d-flex">
            <div class="col-lg-6">
                <div class="card1 pb-5" style="margin-top: 50px;">
                    <div class="row px-3 justify-content-center mb-5 border-line"> <img src="../icon.png" height="270" width="300" style="border-radius: 5px"> </div>
                    
                
                </div>
            </div>
            <div class="col-lg-6" style="margin-top: 30px;">
                <div class="card2 card border-0 px-4 py-5">
                    <div class="row px-6"> 
                       <div class="col-lg-12" style="text-align: center;">
                            <h3>Anda Masuk Sebagai <b><?php 
                                include '../inc/koneksi.php';
                                $kd_kantor = $_SESSION['username'];
                                $sql = "select * from kantor where kode_kantor ='$kd_kantor'";
                                $q = mysqli_query($con, $sql) or die(mysql_error());
                                while ($data = mysqli_fetch_array($q)){
                                echo $data['nama_kantor'];    
                                };
                                
                            ?>
                            <b></h3></div>
                    </div><br>
                        <?php if($_SESSION['username'] == 'admin'){ 

                            echo '<div class="row px-2">
                            <a class="btn btn-secondary btn-lg btn-block" href="mohon-hapus.php" role="button">Permohonan Penghapusan Data</a>
                            </div><br>
                            <div class="row px-2">
                            <a class="btn btn-secondary btn-lg btn-block" href="tindak_lanjut/tindak_lanjut.php" role="button">Tindak Lanjut</a>
                        </div><br>
                            <div class="row px-2">
                            <a class="btn btn-secondary btn-lg btn-block" href="search/input-data.php" role="button">Input Data</a>
                            </div><br>
                            <div class="row px-2">
                            <a class="btn btn-secondary btn-lg btn-block" href="input_user.php" role="button">Input User</a>
                            </div>';
                         }  else {
                             echo '<div class="row px-2">
                            <a class="btn btn-secondary btn-lg btn-block" href="search/cari.php" role="button">Pencarian Data</a>
                        </div><br>
                    
                        <div class="row px-2">
                            <a class="btn btn-secondary btn-lg btn-block" href="tindak_lanjut/tindak_lanjut.php" role="button">Tindak Lanjut</a>
                        </div><br>
                        <div class="row px-2">
                            <a class="btn btn-secondary btn-lg btn-block" href="search/input-data.php" role="button">Input Data</a>
                        </div>
                        ';
                               
                        }?>
 
                </div>
            </div>
        </div><br>
        <div class="bg-blue py-4">
            <div class="row px-3"> <small class="ml-4 ml-sm-5 mb-2">Copyright &copy; 2021. All rights reserved.</small>
                <div class="social-contact ml-4 ml-sm-auto"> <span class="fa fa-facebook mr-4 text-sm"></span> <span class="fa fa-google-plus mr-4 text-sm"></span> <span class="fa fa-linkedin mr-4 text-sm"></span> <span class="fa fa-twitter mr-4 mr-sm-5 text-sm"></span> </div>
            </div>
        </div>
    </div>
</div>

</div>-->

  <script src="../assets/js/jquery.slim.js"></script>
  <script src="../assets/js/bootstrap.bundle.js"></script>
</body>
</html>