<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Aplikasi Barang yang Menjadi Milik Negara</title>

  <!-- Bootstrap core CSS -->
  <link href="../assets/css/bootstrap.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/fonts/css/all.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/login.css">
  
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
 
  <!-- Bootstrap core JavaScript -->
  <script src="../assets/js/jquery.slim.js"></script>
  <script src="../assets/js/bootstrap.bundle.js"></script>
</head>

<body>

<!-- Cek Login -->
<?php include '../inc/cek-login.php'; ?>



  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">Aplikasi Barang yang Menjadi Milik Negara</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">

        <a class="btn" style="background-color:white;color:grey;" href="index.php">Back to Home</a>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i> <?php echo $_SESSION['username'];?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="pass.php"><i class="fas fa-cog"></i> Ganti Password ..</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div  class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-3 mx-auto">

  <h2 class="py-3">Permohonan Penghapusan</h2>
         
  <table id="example" class="table table-striped table-bordered" style="width: 100%;">
    <thead>
      <tr>
        <th>No</th>
        <th>No.SKEP BMN</th>
        <th>Tgl SKEP BMN</th>
        <th>Nomor Dokumen</th>
        <th>Tanggal Dokumen</th>
        <th>Berkas Permohonan</th>
        <th>Keterangan</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php 
  include "../inc/koneksi.php";
  $query_data = "SELECT tbl_utama.no_skep_bmn, tbl_utama.tgl_skep_bmn, dokumen_asal.no_dokumen, dokumen_asal.tgl_dokumen, mohon_hapus.berkas_permohonan, tbl_utama.keterangan FROM `tbl_utama` INNER JOIN dokumen_asal on tbl_utama.no_skep_bmn = dokumen_asal.no_skep_bmn INNER JOIN mohon_hapus on mohon_hapus.no_skep_bmn = tbl_utama.no_skep_bmn";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
       $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
     $nomor++;
     $berkas_permohonan = $data['berkas_permohonan'];
     $no_skep = $data['no_skep_bmn'];
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td style="width: 50px;"><?php echo $no_skep; ?></td>
        <td><?php echo $data['tgl_skep_bmn']; ?></td>
        <td style="width: 50px;"><?php echo $data['no_dokumen']; ?></td>
        <td style="width: 50px;"><?php echo $data['tgl_dokumen']; ?></td>
        <td style="width: 50px;"><a href="upload_hapus/<?php echo $berkas_permohonan;?>"><?php echo $berkas_permohonan; ?></a></td>
        <td style="width: 100px;"><?php echo $data['keterangan']; ?></td>
        <td class="md-2 form-inline">
          <a href="#terima"><button type="button" class="btn btn-success" data-toggle="modal" data-target="#terima">Terima</button></a> 
          <a style="margin-left: 10px;" href="#hapus"><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#hapus">Tolak</button></a>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>

  </div>

  <div class="modal fade" id="terima" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Permohonan Penghapusan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <label>Apakah Anda Yakin untuk Menghapus Data ?</label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
       <a href="hapus.php?terima=<?php echo $no_skep; ?>"><button type="button" class="btn btn-primary">Ya</button></a>
      </div>
    </div>
  </div>
</div>

  <div class="modal fade" id="hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Permohonan Penghapusan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <label>Apakah Anda Yakin Menolak Penghapusan Data ?</label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <a class="btn btn-primary" href="hapus.php?tolak=<?php echo $no_skep; ?>">Ya</a>
      </div>
    </div>
  </div>
</div>

</body>
<script> 
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
 <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script type="text/javascript" src=https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js></script>
  <script type="text/javascript" src=https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js></script>
</html>