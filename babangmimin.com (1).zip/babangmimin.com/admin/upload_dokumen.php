<?php
 
$rand = rand();
$ekstensi =  array('png','jpg','jpeg','gif','pdf');
$file_skep = $_FILES['upbmn']['name'];
$ukuran = $_FILES['upbmn']['size'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);
 
if(!in_array($ext,$ekstensi) ) {
  header("location:index.php?alert=gagal_ekstensi");
}else{
  if($ukuran < 1044070){    
    $xx = $rand.'_'.$filename;
    move_uploaded_file($_FILES['upbmn']['tmp_name'], '../upload_skep'.$rand.'_'.$filename);
    $ins_data = "INSERT INTO tbl_utama (`id`, `no_urut`, `no_skep_bmn`, `tgl_skep_bmn`, `up_bmn`, nama_barang, `spesifikasi_barang`, `jumlah_barang`, `satuan_barang`, `keterangan`) VALUES('','$norut', '$nobmn','$tglbmn','$xx','$namabarang','$spekbarang','$jumbar','$satbar','$ketbar')";

  $query_data = mysqli_query($con, $ins_data); 
    // mysqli_query($con, "INSERT INTO user VALUES(NULL,'$nama','$kontak','$alamat','$xx')");
    header("location:index.php?alert=berhasil");
  }else{
    header("location:index.php?alert=gagak_ukuran");
  }
}


?>