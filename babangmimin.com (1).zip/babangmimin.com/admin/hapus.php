<?php
include '../inc/koneksi.php';


if(isset($_GET['tolak'])){
	$tolak = $_GET['tolak'];	
	mysqli_query($con, "DELETE FROM mohon_hapus WHERE no_skep_bmn='$tolak'")or die(mysqli_error());
	header("location:index.php?pesan=tolak"); 
}

if(isset($_GET['terima'])){
	$terima = $_GET['terima'];
	mysqli_query($con, "DELETE FROM tbl_utama WHERE no_skep_bmn = '$terima'") or die (mysqli_error());

	mysqli_query($con, "DELETE FROM dokumen_asal WHERE no_skep_bmn = '$terima'") or die (mysqli_error());

	mysqli_query($con, "DELETE FROM penilaian WHERE no_skep_bmn = '$terima'") or die (mysqli_error());

	mysqli_query($con, "DELETE FROM tindak_lanjut WHERE no_skep_bmn = '$terima'") or die (mysqli_error());

	mysqli_query($con, "DELETE FROM penyelesaian WHERE no_skep_bmn = '$terima'") or die (mysqli_error());

	mysqli_query($con, "DELETE FROM usulan WHERE no_skep_bmn = '$terima'") or die (mysqli_error());

	mysqli_query($con, "DELETE FROM persetujuan WHERE no_skep_bmn = '$terima'") or die (mysqli_error());

	header("location:index.php?pesan=terima"); 
}

?>