<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Aplikasi Barang yang Menjadi Milik Negara</title>

  <!-- Bootstrap core CSS -->
  <link href="../../assets/css/bootstrap.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../assets/fonts/css/all.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/login.css">
  
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
 
  <!-- Bootstrap core JavaScript -->
  <script src="../../assets/js/jquery.slim.js"></script>
  <script src="../../assets/js/bootstrap.bundle.js"></script>
</head>

<body>

<!-- Cek Login -->
<?php include '../inc/cek-login.php'; ?>


  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">Aplikasi Barang yang Menjadi Milik Negara</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <!-- <li class="nav-item active">
            <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
        </ul> -->
    
        <a class="btn" style="background-color:white;color:grey;"  href="index.php">Back to Home</a>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i> <?php echo $_SESSION['username'];?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="pass.php"><i class="fas fa-cog"></i> Ganti Password ..</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-3 mx-auto">
  <h2 class="py-3">Nama dan Kode Kantor</h2>
          
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th>No</th>
        <th>Kode Kantor</th>
        <th>Nama Kantor</th>
        <th>Satuan Kerja</th>
      </tr>
    </thead>
    <tbody>
    <?php 
  include "../inc/koneksi.php";
  $query_data = "SELECT * FROM kantor";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
     $nomor++;
     
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['kode_kantor']; ?></td>
        <td><?php echo $data['nama_kantor']; ?></td>
        <td><?php echo $data['satuan_kerja']; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
  </div>

</body>
<script> 
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
 <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script type="text/javascript" src=https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js></script>
  <script type="text/javascript" src=https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js></script>

</html>