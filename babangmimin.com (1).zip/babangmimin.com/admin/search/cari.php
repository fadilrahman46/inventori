<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Barang yang Menjadi Milik Negara</title> </head>

  <link href="../assets/css/bootstrap.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../assets/fonts/css/all.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/login.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.css">

</head>

<body>
<?php include '../../inc/cek-login.php'; ?>


<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="../index.php">Aplikasi Barang yang Menjadi Milik Negara</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">

    <a class="btn" style="background-color:white;color:grey;" href="../index.php">Back to Home</a>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i> <?php echo $_SESSION['username'];?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="../pass.php"><i class="fas fa-cog"></i> Ganti Password ..</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </ul>
      </div>
    </div>
  </nav>

<div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
<?php 
    if(isset($_GET['alert'])){
      if($_GET['alert']=='gagal_ekstensi'){
        ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-warning"></i> Peringatan !</h4>
          Ekstensi Tidak Diperbolehkan
        </div>                
        <?php
      }elseif($_GET['alert']=="gagal_ukuran"){
        ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-check"></i> Peringatan !</h4>
          Ukuran File terlalu Besar
        </div>                
        <?php
      }elseif($_GET['alert']=="berhasil"){
        ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-check"></i> Success</h4>
          Berhasil Disimpan
        </div>                
        <?php
      }
    }
    ?>


  
    <div class="card card0 border-0" style="background-color: #6751b7">
        <div class="row d-flex">
            <div class="col-lg-6">
                <div class="card1 pb-5" style="margin-top: 50px;">
                    <div class="row px-3 justify-content-center mb-5 border-line"> <img src="../../icon.png" height="270" width="300" style="border-radius: 5px"> </div>
                    <span class="row px-3 justify-content-center"><button class="btn btn-danger" type="button" onclick="history.back();">Back</button> <a class="btn" style="margin-left: 10px; background-color:#28156f
;color:white;" href="../tindak_lanjut/tindak_lanjut.php" role="button">Tindak Lanjut</a></span>
                </div>
            </div>
            <div class="col-lg-6" style="margin-top: 30px;">
                <div class="card2 card border-0 px-4 py-4">
                    <div class="col-lg-12" style="text-align:center;"> 
                      <label><h3>Pencarian Data</h3></label>
                    </div><br>
                    <div class="col-lg-12">
                      <form method="GET" action="hasil_cari.php">
                        <div class="form-inline mb-3">
                            <label class="form-label">No SKEP BMN : </label>
                            <input class="form-control" style="margin-left: 14px; width:70%" name="skep_bmn">
                        </div>
                        
                        <div class="form-inline mb-3">
                            <label class="form-label">Tgl SKEP BMN : </label>
                            <div class="col-sm-6">
                            <input class="form-control"  type="date" name="tgl_awal" style="width:100%">
                            </div>
                            <div class="col-sm-6">
                            <input class="form-control"  type="date" name="tgl_akhir" style="margin-left: 107px; margin-top: 5px; width:100%">
                            </div>
                        </div>
                        <div class="form-inline mb-3">
                        <label class="form-label">Peruntukan : </label>
                        <select class="form-control" name="peruntukan" style="margin-left: 35px; width:70%">
                          <option value=""></option>  
                          <option value="penilaian">Penilaian</option>
                          <option value="persetujuan">Persetujuan</option>
                          <option value="usulan">Usulan</option>
                          <option value="penyelesaian">Penyelesaian</option>
                        </select>
                      </div>

                        <div class="form-inline mb-3">
                            <label class="form-label">Nama Barang : </label>
                            <input class="form-control" name="nama_barang" style="margin-left: 20px; width:70%">
                        </div>
                        
                        <input class="btn btn-primary" type="submit" name="submit" value="cari">
                        
                      </form>
                      </div>
                </div>
            </div>
        </div><br>
        <div class="bg-blue py-4">
            <div class="row px-3"> <small class="ml-4 ml-sm-5 mb-2">Copyright &copy; 2021. All rights reserved.</small>
                <div class="social-contact ml-4 ml-sm-auto"> <span class="fa fa-facebook mr-4 text-sm"></span> <span class="fa fa-google-plus mr-4 text-sm"></span> <span class="fa fa-linkedin mr-4 text-sm"></span> <span class="fa fa-twitter mr-4 mr-sm-5 text-sm"></span> </div>
            </div>
        </div>
    </div>
</div>


</body>
  <script src="../../assets/js/jquery.slim.js"></script>
  <script src="../../assets/js/bootstrap.bundle.js"></script>
</html>