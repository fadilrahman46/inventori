<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Aplikasi Barang yang Menjadi Milik Negara</title>

  <!-- Bootstrap core CSS -->
  <link href="../../assets/css/bootstrap.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../assets/fonts/css/all.css">
  <link rel="stylesheet" href="../../assets/fonts/css/fontawesome.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/login.css">


   <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
 
  <!-- Bootstrap core JavaScript -->
  <script src="../../assets/js/jquery.slim.js"></script>
  <script src="../../assets/js/bootstrap.bundle.js"></script>

</head>

<body>

<!-- Cek Login -->
<?php include '../../inc/cek-login.php'; ?>



  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">Aplikasi Barang yang Menjadi Milik Negara</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
       
        <a class="btn" style="background-color:white;color:grey;" href="cari.php">Back to Search</a>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i> <?php echo $_SESSION['username'];?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="../pass.php"><i class="fas fa-cog"></i> Ganti Password ..</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container-fluid px-1 px-md-3 px-lg-1 px-xl-5 py-3 mx-auto">
  
  
<?php
if(isset($_GET['submit'])){
  if($_GET['skep_bmn']){
    $skep_bmn=$_GET['skep_bmn'];
    include 'skep_bmn.php';
  } elseif($_GET['tgl_awal'] OR $_GET['tgl_akhir']){
    $tgl_awal=$_GET['tgl_awal'];
    $tgl_akhir=$_GET['tgl_akhir'];
    include 'tgl_bmn.php';
  } elseif($_GET['peruntukan']){
    $peruntukan=$_GET['peruntukan'];    
    include 'peruntukan.php';
  } elseif($_GET['nama_barang']) {
    $nama_barang=$_GET['nama_barang'];
    include 'nama_barang.php';
  } else {
      include 'cari_all.php';
  }  

}
?>
  </div>

</body>
<script> 
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
 <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script type="text/javascript" src=https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js></script>
  <script type="text/javascript" src=https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js></script>
</html>