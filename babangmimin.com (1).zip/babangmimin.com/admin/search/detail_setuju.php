<?php
// Detail Uraian Tanggal
  include "../../inc/koneksi.php";
  if(!empty($_GET['awal']) and !empty($_GET['akhir']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th colspan="4">Dokumen Persetujuan</th>
        
        <th rowspan="2">Bentuk Persetujuan</th>
        <th rowspan="2">Keterangan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Asal Surat</td>
        <td>Berkas</td>
      </tr>
    </thead>
      <tbody>
      <?php 

    $no_skep = $_GET['no_skep'];
    $tgl_awal = $_GET['awal'];
    $tgl_akhir = $_GET['akhir'];

    $query_data = "SELECT DISTINCT persetujuan.no_pengajuan, persetujuan.tgl_pengajuan, persetujuan.tgl_persetujuan, persetujuan.no_persetujuan, persetujuan.dok_persetujuan, persetujuan.bentuk_persetujuan, persetujuan.ket_persetujuan, persetujuan.dok_pengajuan, dokumen_asal.asal_dokumen FROM persetujuan INNER JOIN dokumen_asal on persetujuan.no_skep_bmn = dokumen_asal.no_skep_bmn inner join tbl_utama on tbl_utama.no_skep_bmn = persetujuan.no_skep_bmn where tbl_utama.tgl_skep_bmn between '$tgl_awal' and '$tgl_akhir' and persetujuan.no_skep_bmn ='$no_skep'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['no_pengajuan'];?></td>
        <td><?php echo $data['tgl_pengajuan']; ?></td>
        <td><?php echo $data['no_persetujuan']; ?></td>
        <td><?php echo $data['tgl_persetujuan']; ?></td>
        <td><?php echo $data['asal_dokumen']; ?></td>
        <td><a href="../upload_peruntukan/<?php echo $data['dok_persetujuan']; ?>"><?php echo $data['dok_persetujuan']; ?></a></td>
        <td><?php echo $data['bentuk_persetujuan']; ?></td>
        <td><?php echo $data['ket_persetujuan']; ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
<?php } else {
?>

<?php 
// Detail Uraian Nama Barang
  if(!empty($_GET['nm_bar']) and !empty($_GET['no_skep'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th colspan="4">Dokumen Persetujuan</th>
        
        <th rowspan="2">Bentuk Persetujuan</th>
        <th rowspan="2">Keterangan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Asal Surat</td>
        <td>Berkas</td>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];
  $nm_bar = $_GET['nm_bar'];

  $query_data = "SELECT DISTINCT persetujuan.no_pengajuan, persetujuan.tgl_pengajuan, persetujuan.tgl_persetujuan, persetujuan.no_persetujuan, persetujuan.dok_persetujuan, persetujuan.bentuk_persetujuan, persetujuan.ket_persetujuan, persetujuan.dok_pengajuan, dokumen_asal.asal_dokumen FROM persetujuan INNER JOIN dokumen_asal on persetujuan.no_skep_bmn = dokumen_asal.no_skep_bmn inner join tbl_utama on tbl_utama.no_skep_bmn = persetujuan.no_skep_bmn where tbl_utama.nama_barang = '$nm_bar' and persetujuan.no_skep_bmn ='$no_skep'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['no_pengajuan'];?></td>
        <td><?php echo $data['tgl_pengajuan']; ?></td>
        <td><?php echo $data['no_persetujuan']; ?></td>
        <td><?php echo $data['tgl_persetujuan']; ?></td>
        <td><?php echo $data['asal_dokumen']; ?></td>
        <td><a href="../upload_peruntukan/<?php echo $data['dok_persetujuan']; ?>"><?php echo $data['dok_persetujuan']; ?></a></td>
        <td><?php echo $data['bentuk_persetujuan']; ?></td>
        <td><?php echo $data['ket_persetujuan']; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } else {
?>

<?php
//Detail Uraian Status Peruntukan
     if(!empty($_GET['status']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th colspan="4">Dokumen Persetujuan</th>
       
        <th rowspan="2">Bentuk Persetujuan</th>
        <th rowspan="2">Keterangan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Asal Surat</td>
        <td>Berkas</td>
      </tr>
    </thead>
      <tbody>
      <?php 
      
    $no_skep = $_GET['no_skep'];
    $status = $_GET['status'];

    $query_data = "SELECT DISTINCT persetujuan.no_pengajuan, persetujuan.tgl_pengajuan, persetujuan.tgl_persetujuan, persetujuan.no_persetujuan, persetujuan.dok_persetujuan, persetujuan.bentuk_persetujuan, persetujuan.ket_persetujuan, persetujuan.dok_pengajuan, dokumen_asal.asal_dokumen FROM persetujuan INNER JOIN dokumen_asal on persetujuan.no_skep_bmn = dokumen_asal.no_skep_bmn inner join tbl_utama on tbl_utama.no_skep_bmn = persetujuan.no_skep_bmn where persetujuan.no_skep_bmn ='$no_skep'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['no_pengajuan'];?></td>
        <td><?php echo $data['tgl_pengajuan']; ?></td>
        <td><?php echo $data['no_persetujuan']; ?></td>
        <td><?php echo $data['tgl_persetujuan']; ?></td>
        <td><?php echo $data['asal_dokumen']; ?></td>
        <td><a href="../upload_peruntukan/<?php echo $data['dok_persetujuan']; ?>"><?php echo $data['dok_persetujuan']; ?></a></td>
        <td><?php echo $data['bentuk_persetujuan']; ?></td>
        <td><?php echo $data['ket_persetujuan']; ?></td>
        <?php } ?>
      </tbody>
    </table>
<?php }  else {
?>

<?php 
// Detail Uraian No Skep
  if(!empty($_GET['no_skep']) and empty($_GET['awal']) and empty($_GET['akhir']) and empty($_GET['nm_bar']) and empty($_GET['status'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th colspan="4">Dokumen Persetujuan</th>
      
        <th rowspan="2">Bentuk Persetujuan</th>
        <th rowspan="2">Keterangan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Asal Surat</td>
        <td>Berkas</td>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];

  $query_data = "SELECT DISTINCT persetujuan.no_pengajuan, persetujuan.tgl_pengajuan, persetujuan.tgl_persetujuan, persetujuan.no_persetujuan, persetujuan.dok_persetujuan, persetujuan.bentuk_persetujuan, persetujuan.ket_persetujuan, persetujuan.dok_pengajuan, dokumen_asal.asal_dokumen FROM persetujuan INNER JOIN dokumen_asal on persetujuan.no_skep_bmn = dokumen_asal.no_skep_bmn inner join tbl_utama on tbl_utama.no_skep_bmn = persetujuan.no_skep_bmn where persetujuan.no_skep_bmn ='$no_skep'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['no_pengajuan'];?></td>
        <td><?php echo $data['tgl_pengajuan']; ?></td>
        <td><?php echo $data['no_persetujuan']; ?></td>
        <td><?php echo $data['tgl_persetujuan']; ?></td>
        <td><?php echo $data['asal_dokumen']; ?></td>
        <td><a href="../upload_peruntukan/<?php echo $data['dok_persetujuan']; ?>"><?php echo $data['dok_persetujuan']; ?></a></td>
        <td><?php echo $data['bentuk_persetujuan']; ?></td>
        <td><?php echo $data['ket_persetujuan']; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } 
} 
} 
}
?>





