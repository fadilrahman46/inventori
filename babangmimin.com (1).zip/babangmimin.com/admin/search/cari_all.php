
  <label><b style="font-size: 25px;">Hasil Pencarian Semua Data</b> <label>    
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th>No</th>
        <th>No.SKEP BMN</th>
        <th>Tgl SKEP BMN</th>
        <th>Dokumen Asal</th>
        <th>Nilai Limit</th>
        <th>Peruntukan</th>
        <th>Kantor</th>
        <th>Status</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php
  include "../../inc/koneksi.php";
  
  $query_data = "SELECT Distinct tbl_utama.no_skep_bmn, tbl_utama.tgl_skep_bmn, dokumen_asal.asal_dokumen, tindak_lanjut.nilai_limit, tindak_lanjut.status, dokumen_asal.keterangan_dok, kantor.nama_kantor FROM tbl_utama INNER JOIN dokumen_asal on tbl_utama.no_skep_bmn = dokumen_asal.no_skep_bmn INNER JOIN tindak_lanjut on tindak_lanjut.no_skep_bmn = tbl_utama.no_skep_bmn INNER JOIN kantor on tbl_utama.kode_kantor = kantor.kode_kantor ";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
  $nomor=0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
    $hapus_skep = $data['no_skep_bmn'];
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['no_skep_bmn']; ?></td>
        <td><?php echo $data['tgl_skep_bmn']; ?></td>
        <td><?php echo $data['asal_dokumen']; ?></td>
        <td><?php echo $data['nilai_limit']; ?></td>
        <td><?php echo $data['keterangan_dok']; ?></td>
        <td><?php echo $data['nama_kantor']; ?></td>
        <td><?php echo $data['status']; ?></td>
        <td><a href="detail.php?detail=uraian&no_skep=<?php echo $hapus_skep;?>&nm_bar=<?php echo $nama_barang; ?>"><i class="fa fa-search" aria-hidden="true"></i></a>
          <a href="../tindak_lanjut/form_penghapusan.php?hapus=<?php echo $hapus_skep; ?>"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
