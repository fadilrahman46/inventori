<?php 
include '../../inc/koneksi.php';

$nobmn = $_POST['nobmn'];
$tglbmn = $_POST['tglbmn'];
#$upbmn = $_POST['upbmn'];
//data barang
$norut = $_POST['norut'];
$namabarang = $_POST['namabarang'];
$spekbarang = $_POST['spekbarang'];
$jumbar = $_POST['jumbar'];
$satbar = $_POST['satbar']; 
$ketbar = $_POST['ketbar'];
//dokumen asal
$asaldok = $_POST['asaldok'];
$nodok = $_POST['nodok'];
#$updok = $_POST['updok'];
$ketdok = $_POST['ketdok'];
$tgldok = $_POST['tgldok'];
$kd_kantor = $_POST['kd_kantor'];



$rand = rand();
$ekstensi =  array('png','jpg','jpeg','gif','pdf');

$file_skep = $_FILES['upbmn']['name'];
$ukuran_skep = $_FILES['upbmn']['size'];
$ext_skep = pathinfo($file_skep, PATHINFO_EXTENSION);


if(!in_array($ext_skep,$ekstensi) ) {
  header("location:index.php?alert=gagal_ekstensi");
}else{
  if($ukuran_skep < 1044070){    
    $xx = $rand.'_skep.'.$ext_skep;
    move_uploaded_file($_FILES['upbmn']['tmp_name'], '../upload_skep/'.$xx);
    $ins_data = "INSERT INTO tbl_utama (`id`, `no_urut`, `no_skep_bmn`, `tgl_skep_bmn`, `up_bmn`, nama_barang, `spesifikasi_barang`, `jumlah_barang`, `satuan_barang`, kode_kantor, `keterangan`) VALUES('','$norut', '$nobmn','$tglbmn','$xx','$namabarang','$spekbarang','$jumbar','$satbar','$kd_kantor','$ketbar')";

    $query_data = mysqli_query($con, $ins_data); 
    // mysqli_query($con, "INSERT INTO user VALUES(NULL,'$nama','$kontak','$alamat','$xx')");
    header("location:input-data.php?alert=berhasil");
  }else{
    header("location:input-data.php?alert=gagal_ukuran");
  }
}

$tindak_lanjut = "INSERT INTO tindak_lanjut (id, no_skep_bmn) values ('','$nobmn')";
$q_tindak_lanjut = mysqli_query($con, $tindak_lanjut);

$penilai = "INSERT INTO penilaian (id, no_skep_bmn) values ('',$nobmn)";
$q_penilai = mysqli_query($con, $penilai);

$usulan = "INSERT INTO usulan (id, no_skep_bmn) values ('',$nobmn)";
$q_usulan = mysqli_query($con, $usulan);

$persetujuan = "INSERT INTO persetujuan (id, no_skep_bmn) values ('',$nobmn)";
$q_persetujuan = mysqli_query($con, $persetujuan);

$penyelesaian = "INSERT INTO penyelesaian (id, no_skep_bmn) values ('',$nobmn)";
$q_penyelesaian = mysqli_query($con, $penyelesaian);

$file_dok = $_FILES['updok']['name'];
$ukuran_dok = $_FILES['updok']['size'];
$ext_dok = pathinfo($file_dok, PATHINFO_EXTENSION);
 

if(!in_array($ext_dok,$ekstensi) ) {
  header("location:input-data.php?alert=gagal_ekstensi");
}else{
  if($ukuran_dok < 1044070){    
    $yy = $rand.'_dok.'.$ext_dok;
    move_uploaded_file($_FILES['updok']['tmp_name'], '../upload_dokumen/'.$yy);
    $ins_dok = "INSERT INTO dokumen_asal (`id`, `no_skep_bmn`, `asal_dokumen`, `tgl_dokumen`, `no_dokumen`, `upload_dokumen`, `keterangan_dok`) VALUES('','$nobmn', '$asaldok','$tgldok','$nodok','$yy','$ketdok')";

    $query_dok = mysqli_query($con, $ins_dok);
    // mysqli_query($con, "INSERT INTO user VALUES(NULL,'$nama','$kontak','$alamat','$xx')");
    header("location:input-data.php?alert=berhasil");
  }else{
    header("location:input-data.php?alert=gagal_ukuran");
  }
}

if(isset($_GET['aksi'])){
    
    if($_GET['aksi']=='user'){
        $kode_kantor = $_POST['kode_kantor'];
        $nama_kantor = $_POST['nama_kantor'];
        $password = md5($_POST['kode_kantor']);
        $cek = "SELECT * from admin where kode_kantor ='$kode_kantor' or nama_kantor = '$nama_kantor'";
        $query_cek = mysqli_query($con, $cek);
        $cek_admin = mysqli_num_rows($query_cek);
        
        $cek_k = "SELECT * from kantor where kode_kantor ='$kode_kantor' or nama_kantor = '$nama_kantor'";
        $kantor = mysqli_query($con, $cek_k);
        $cek_kantor = mysqli_num_rows($kantor);
        
        if($cek_admin > 0 ){
            header("location:../input_user.php?alert=gagaladmin");    
        } else {
            if($cek_kantor == 0){ 
            header("location:../input_user.php?alert=gagalkantor");        
            } else {
        $q = "INSERT INTO `admin`(`id`, `username`, `password`, `kode_kantor`, `nama_kantor`) VALUES ('', '$kode_kantor', '$password','$kode_kantor','$nama_kantor')";
        $query_user = mysqli_query($con,$q);
        header("location:../input_user.php?alert=berhasil");
        
    }
}
}

}




?>