<?php
// Detail Uraian Tanggal
  include "../../inc/koneksi.php";
  if(!empty($_GET['awal']) and !empty($_GET['akhir']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Barang</th>
          <th>Spesifikasi</th>
          <th>Jumlah</th>
          <th>Satuan</th>
          <th>Keterangan</th>
        </tr>
      </thead>
      <tbody>
      <?php 

    $no_skep = $_GET['no_skep'];
    $tgl_awal = $_GET['awal'];
    $tgl_akhir = $_GET['akhir'];

    $query_data = "SELECT DISTINCT nama_barang, spesifikasi_barang, jumlah_barang, satuan_barang, keterangan from tbl_utama where tgl_skep_bmn between '$tgl_awal' and '$tgl_akhir'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
          <td><?php echo $nomor; ?></td>
          <td><?php echo $data['nama_barang']; ?></td>
          <td><?php echo $data['spesifikasi_barang']; ?></td>
          <td><?php echo $data['jumlah_barang']; ?></td>
          <td><?php echo $data['satuan_barang']; ?></td>
          <td><?php echo $data['keterangan']; ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
<?php } else {
?>

<?php 
// Detail Uraian Nama Barang
  if(!empty($_GET['nm_bar']) and !empty($_GET['no_skep'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Barang</th>
        <th>Spesifikasi</th>
        <th>Jumlah</th>
        <th>Satuan</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];
  $nm_bar = $_GET['nm_bar'];

  $query_data = "SELECT DISTINCT nama_barang, spesifikasi_barang, jumlah_barang, satuan_barang, keterangan from tbl_utama where nama_barang = '$nm_bar'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['nama_barang']; ?></td>
        <td><?php echo $data['spesifikasi_barang']; ?></td>
        <td><?php echo $data['jumlah_barang']; ?></td>
        <td><?php echo $data['satuan_barang']; ?></td>
        <td><?php echo $data['keterangan']; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } else {
?>

<?php
//Detail Uraian Status Peruntukan
     if(!empty($_GET['status']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Barang</th>
          <th>Spesifikasi</th>
          <th>Jumlah</th>
          <th>Satuan</th>
          <th>Keterangan</th>
        </tr>
      </thead>
      <tbody>
      <?php 
      
    $no_skep = $_GET['no_skep'];
    $status = $_GET['status'];

    $query_data = "SELECT DISTINCT tbl_utama.nama_barang, tbl_utama.spesifikasi_barang, tbl_utama.jumlah_barang, tbl_utama.satuan_barang, tbl_utama.keterangan from tbl_utama inner join tindak_lanjut on tbl_utama.no_skep_bmn = tindak_lanjut.no_skep_bmn where tindak_lanjut.status = '$status'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
          <td><?php echo $nomor; ?></td>
          <td><?php echo $data['nama_barang']; ?></td>
          <td><?php echo $data['spesifikasi_barang']; ?></td>
          <td><?php echo $data['jumlah_barang']; ?></td>
          <td><?php echo $data['satuan_barang']; ?></td>
          <td><?php echo $data['keterangan']; ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
<?php }  else {
?>

<?php 
// Detail Uraian No Skep
  if(!empty($_GET['no_skep']) and empty($_GET['awal']) and empty($_GET['akhir']) and empty($_GET['nm_bar']) and empty($_GET['status'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Barang</th>
        <th>Spesifikasi</th>
        <th>Jumlah</th>
        <th>Satuan</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];

  $query_data = "SELECT DISTINCT nama_barang, spesifikasi_barang, jumlah_barang, satuan_barang, keterangan from tbl_utama where no_skep_bmn = '$no_skep'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['nama_barang']; ?></td>
        <td><?php echo $data['spesifikasi_barang']; ?></td>
        <td><?php echo $data['jumlah_barang']; ?></td>
        <td><?php echo $data['satuan_barang']; ?></td>
        <td><?php echo $data['keterangan']; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } 
} 
} 
}
?>
