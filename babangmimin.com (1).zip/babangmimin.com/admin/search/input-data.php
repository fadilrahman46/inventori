<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Barang yang Menjadi Milik Negara</title> <!-- CSS -->

  <link href="../assets/css/bootstrap.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../assets/fonts/css/all.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/login.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.css">

</head>
<style>
* {
  box-sizing: border-box;
}

body {
  background-color: #f1f1f1;
}

#regForm {
  background-color: #ffffff;
  margin: 50px auto;
  font-family: Raleway;
  padding: 40px;
  width: 70%;
  min-width: 450px;
}

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #6751b7;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #6751b7;
}
</style>

<body>
<?php include '../../inc/cek-login.php'; ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="../index.php">Aplikasi Barang yang Menjadi Milik Negara</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <!-- <li class="nav-item active">
            <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
        </ul> -->
        <a class="btn" style="background-color:white;color:grey;" href="../index.php">Back to Home</a>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i> <?php echo $_SESSION['username'];?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="../pass.php"><i class="fas fa-cog"></i> Ganti Password ..</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </ul>
      </div>
    </div>
  </nav>


<div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
  <?php 
    if(isset($_GET['alert'])){
      if($_GET['alert']=='gagal_ekstensi'){
        ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-warning"></i> Peringatan !</h4>
          Ekstensi Tidak Diperbolehkan
        </div>                
        <?php
      }elseif($_GET['alert']=="gagal_ukuran"){
        ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-check"></i> Peringatan !</h4>
          Ukuran File terlalu Besar
        </div>                
        <?php
      }elseif($_GET['alert']=="berhasil"){
        ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-check"></i> Success</h4>
          Berhasil Disimpan
        </div>                
        <?php
      }
    }
    ?>
    <div class="card card0 border-0" style="background-color: #6751b7">
        <div class="row d-flex">
            <div class="col-lg-6">
                <div class="card1 pb-5" style="margin-top: 50px;">
                    <div class="row px-3 justify-content-center mb-5 border-line"> <img src="../../icon.png" height="270" width="300" style="border-radius: 5px"> </div>
                    <span class="row px-3 justify-content-center"><button class="btn" style="background-color:#28156f
;color:white;" type="button" onclick="history.back();">Back</button></span>          
                </div>
            </div>
            <div class="col-lg-6">
                
                    <form id="regForm" method="POST" action="input-aksi.php" enctype="multipart/form-data">
  
  <!-- One "tab" for each step in the form: -->
                      <div class="tab form-group">
                        <h2>Input Data Baru : </h2>
                        <label>No SKEP BMN</label>
                        <p><input class="form-control" placeholder="No SKEP BMN" oninput="this.className = ''" name="nobmn"></p>
                        <label>Tanggal SKEP BMN</label>
                        <p><input class="form-control" type ="date" placeholder="Tanggal SKEP BMN" oninput="this.className = ''" name="tglbmn"></p>
                        <label>Upload SKEP BMN</label>
                        <p><input type="file" placeholder="Upload SKEP BMN" oninput="this.className = ''" name="upbmn"></p>
                        
                        <?php if($_SESSION['username']=='admin'){ ?> 
                        <label>Kantor</label>
                        <p><select class="form-control" name="kd_kantor" id="provinsi">
                                  <option value="admin"> Admin </option>
                                 <?php 
                                 include '../../inc/koneksi.php';
                                 $sql="SELECT * FROM kantor where nama_kantor !='admin'";
                                 $query = mysqli_query($con, $sql) or die(mysql_error());
                                  while($data = mysqli_fetch_array($query)) {
                                 ?>
                                   <option value="<?=$data['kode_kantor']?>"><?php echo $data['nama_kantor'] ?></option> 
                                 <?php
                                  }
                                 ?>
                        </select></p> 
                        <?php } else {?>
                        <p><input type="hidden" oninput="this.className = ''" name="kd_kantor" value="<?php echo $_SESSION['username']; ?>"></p>
                        <?php } ?>
                      </div>
                      <div class="tab form-group">
                        <h2>Data Barang</h2>
                        <label>No Urut</label>
                        <p><input class="form-control" type="number" placeholder="No Urut" oninput="this.className = ''" name="norut"></p>
                        <label>Nama Barang</label>
                        <p><input class="form-control" placeholder="Nama Barang" oninput="this.className = ''" name="namabarang"></p>
                        <label>Spesifikasi Barang</label>
                        <p><input class="form-control" placeholder="Spesifikasi Barang" oninput="this.className = ''" name="spekbarang"></p>
                        <label>Jumlah Barang</label>
                        <p><input class="form-control" type="number" placeholder="Jumlah Barang" oninput="this.className = ''" name="jumbar"></p>
                        <label>Satuan Barang</label>
                        <p><input class="form-control" placeholder="Satuan Barang" oninput="this.className = ''" name="satbar"></p>
                        <label>Keterangan Barang</label>
                        <p><textarea class="form-control" placeholder="Keterangan" oninput="this.className = ''" name="ketbar"></textarea></p>
                      </div>
                      <div class="tab form-group">
                        <h2>Dokumen Asal</h2>
                        <label>Asal Dokumen</label>
                        <p><input class="form-control" placeholder="Asal Dokumen" oninput="this.className = ''" name="asaldok"></p>
                        <label>Nomor Dokumen</label>
                        <p><input class="form-control" placeholder="Nomor Dokumen" oninput="this.className = ''" name="nodok"></p>
                        <label>Tanggal Dokumen</label>
                        <p><input class="form-control" type="date" placeholder="Tanggal Dokumen" oninput="this.className = ''" name="tgldok"></p>
                        <label>Upload Dokumen</label>
                        <p><input type="file" placeholder="Upload Dokumen Asal" oninput="this.className = ''" name="updok"></p>
                        <label>Keterangan Dokumen</label>
                        <p><textarea class="form-control" placeholder="Keterangan" oninput="this.className = ''" name="ketdok"></textarea></p>
                      </div>
                      <div style="overflow:auto;">
                        <div style="float:right;">
                          <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                          <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                        </div>
                      </div>
                      <!-- Circles which indicates the steps of the form: -->
                      <div style="text-align:center;margin-top:40px;">
                        <span class="step"></span>
                        <span class="step"></span>
                        <span class="step"></span>
                       
                      </div>
                    </form>
                        <!-- Form -->
                                    
                    
            </div>
            </div>
        </div>
        <div class="bg-blue py-4">
            <div class="row px-3"> <small class="ml-4 ml-sm-5 mb-2">Copyright &copy; 2021. All rights reserved.</small>
                <div class="social-contact ml-4 ml-sm-auto"> <span class="fa fa-facebook mr-4 text-sm"></span> <span class="fa fa-google-plus mr-4 text-sm"></span> <span class="fa fa-linkedin mr-4 text-sm"></span> <span class="fa fa-twitter mr-4 mr-sm-5 text-sm"></span> </div>
            </div>
        </div>
    </div>
</div>

<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";

  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  //document.getElementById("nextBtn").type = "submit"
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    document.getElementById("nextBtn").type = "submit"
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
</script>
  <script src="../../assets/js/jquery.slim.js"></script>
  <script src="../../assets/js/bootstrap.bundle.js"></script>
  <script  src="../../assets/js/form.js" type="text/javascript"></script>

</body>
</html>