<?php
// Detail Uraian Tanggal
  include "../../inc/koneksi.php";
  if(!empty($_GET['awal']) and !empty($_GET['akhir']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th colspan="2">Dokumen Kegiatan</th>
        <th rowspan="2">Bentuk Kegiatan</th>
        <th rowspan="2">Waktu Pelaksanaan</th>
        <th rowspan="2">Foto Kegiatan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Nomor</td>
        <td>Tanggal</td>
      </tr>
    </thead>
      <tbody>
      <?php 

    $no_skep = $_GET['no_skep'];
    $tgl_awal = $_GET['awal'];
    $tgl_akhir = $_GET['akhir'];

    $query_data = "SELECT DISTINCT penyelesaian.no_pengajuan, penyelesaian.tgl_pengajuan, penyelesaian.tgl_kegiatan, penyelesaian.no_kegiatan, penyelesaian.bentuk_kegiatan, penyelesaian.waktu_pelaksanaan, penyelesaian.foto_kegiatan FROM penyelesaian inner join tbl_utama on tbl_utama.no_skep_bmn = penyelesaian.no_skep_bmn where tbl_utama.tgl_skep_bmn between '$tgl_awal' and '$tgl_akhir' and penyelesaian.no_skep_bmn ='$no_skep'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['no_pengajuan'];?></td>
        <td><?php echo $data['tgl_pengajuan']; ?></td>
        <td><?php echo $data['no_kegiatan']; ?></td>
        <td><?php echo $data['tgl_kegiatan']; ?></td>
        <td><?php echo $data['bentuk_kegiatan']; ?></td>
        <td><?php echo $data['waktu_pelaksanaan']; ?></td>
        <td><a href="../foto_kegiatan/<?php echo $data['foto_kegiatan']; ?>"><?php echo $data['foto_kegiatan']; ?></a></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
<?php } else {
?>

<?php 
// Detail Uraian Nama Barang
  if(!empty($_GET['nm_bar']) and !empty($_GET['no_skep'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
   <thead>
      <tr>
        <th rowspan="2">No</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th colspan="2">Dokumen Kegiatan</th>
        <th rowspan="2">Bentuk Kegiatan</th>
        <th rowspan="2">Waktu Pelaksanaan</th>
        <th rowspan="2">Foto Kegiatan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Nomor</td>
        <td>Tanggal</td>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];
  $nm_bar = $_GET['nm_bar'];

  $query_data = "SELECT DISTINCT penyelesaian.no_pengajuan, penyelesaian.tgl_pengajuan, penyelesaian.tgl_kegiatan, penyelesaian.no_kegiatan, penyelesaian.bentuk_kegiatan, penyelesaian.waktu_pelaksanaan, penyelesaian.foto_kegiatan FROM penyelesaian inner join tbl_utama on tbl_utama.no_skep_bmn = penyelesaian.no_skep_bmn where tbl_utama.nama_barang = '$nm_bar' and penyelesaian.no_skep_bmn ='$no_skep'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['no_pengajuan'];?></td>
        <td><?php echo $data['tgl_pengajuan']; ?></td>
        <td><?php echo $data['no_kegiatan']; ?></td>
        <td><?php echo $data['tgl_kegiatan']; ?></td>
        <td><?php echo $data['bentuk_kegiatan']; ?></td>
        <td><?php echo $data['waktu_pelaksanaan']; ?></td>
        <td><a href="../foto_kegiatan/<?php echo $data['foto_kegiatan']; ?>"><?php echo $data['foto_kegiatan']; ?></a></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } else {
?>

<?php
//Detail Uraian Status Peruntukan
     if(!empty($_GET['status']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th colspan="2">Dokumen Kegiatan</th>
        <th rowspan="2">Bentuk Kegiatan</th>
        <th rowspan="2">Waktu Pelaksanaan</th>
        <th rowspan="2">Foto Kegiatan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Nomor</td>
        <td>Tanggal</td>
      </tr>
    </thead>
      <tbody>
      <?php 
      
    $no_skep = $_GET['no_skep'];
    $status = $_GET['status'];

    $query_data = "SELECT DISTINCT penyelesaian.no_pengajuan, penyelesaian.tgl_pengajuan, penyelesaian.tgl_kegiatan, penyelesaian.no_kegiatan, penyelesaian.bentuk_kegiatan, penyelesaian.waktu_pelaksanaan, penyelesaian.foto_kegiatan FROM penyelesaian inner join tbl_utama on tbl_utama.no_skep_bmn = penyelesaian.no_skep_bmn where penyelesaian.no_skep_bmn ='$no_skep'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['no_pengajuan'];?></td>
        <td><?php echo $data['tgl_pengajuan']; ?></td>
        <td><?php echo $data['no_kegiatan']; ?></td>
        <td><?php echo $data['tgl_kegiatan']; ?></td>
        <td><?php echo $data['bentuk_kegiatan']; ?></td>
        <td><?php echo $data['waktu_pelaksanaan']; ?></td>
        <td><a href="../foto_kegiatan/<?php echo $data['foto_kegiatan']; ?>"><?php echo $data['foto_kegiatan']; ?></a></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
<?php }  else {
?>

<?php 
// Detail Uraian No Skep
  if(!empty($_GET['no_skep']) and empty($_GET['awal']) and empty($_GET['akhir']) and empty($_GET['nm_bar']) and empty($_GET['status'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th colspan="2">Dokumen Kegiatan</th>
        <th rowspan="2">Bentuk Kegiatan</th>
        <th rowspan="2">Waktu Pelaksanaan</th>
        <th rowspan="2">Foto Kegiatan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
        <td>Nomor</td>
        <td>Tanggal</td>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];

  $query_data = "SELECT DISTINCT penyelesaian.no_pengajuan, penyelesaian.tgl_pengajuan, penyelesaian.tgl_kegiatan, penyelesaian.no_kegiatan, penyelesaian.bentuk_kegiatan, penyelesaian.waktu_pelaksanaan, penyelesaian.foto_kegiatan FROM penyelesaian inner join tbl_utama on tbl_utama.no_skep_bmn = penyelesaian.no_skep_bmn where penyelesaian.no_skep_bmn ='$no_skep'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['no_pengajuan'];?></td>
        <td><?php echo $data['tgl_pengajuan']; ?></td>
        <td><?php echo $data['no_kegiatan']; ?></td>
        <td><?php echo $data['tgl_kegiatan']; ?></td>
        <td><?php echo $data['bentuk_kegiatan']; ?></td>
        <td><?php echo $data['waktu_pelaksanaan']; ?></td>
        <td><a href="../foto_kegiatan/<?php echo $data['foto_kegiatan']; ?>"><?php echo $data['foto_kegiatan']; ?></a></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } 
} 
} 
}
?>



