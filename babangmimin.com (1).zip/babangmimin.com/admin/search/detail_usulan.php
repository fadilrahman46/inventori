<?php
// Detail Uraian Tanggal
  include "../../inc/koneksi.php";
  if(!empty($_GET['awal']) and !empty($_GET['akhir']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th rowspan="2">No SKEP</th>
        <th rowspan="2">Usulan Peruntukan</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th rowspan="2">Berkas Dokumen</th>
        <th rowspan="2">Tujuan Pengajuan</th>
        <th rowspan="2">Nilai Limit</th>
        <th rowspan="2">Keterangan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
      </tr>
    </thead>
      <tbody>
      <?php 

    $no_skep = $_GET['no_skep'];
    $tgl_awal = $_GET['awal'];
    $tgl_akhir = $_GET['akhir'];

    $query_data = "SELECT DISTINCT usulan.jenis_peruntukan, usulan.no_usulan, usulan.tgl_usulan, usulan.dok_usulan, usulan.tujuan_pengajuan, tindak_lanjut.nilai_limit, usulan.ket_usulan FROM usulan INNER JOIN tindak_lanjut on usulan.no_skep_bmn = tindak_lanjut.no_skep_bmn inner join tbl_utama on usulan.no_skep_bmn = tbl_utama.no_skep_bmn where tbl_utama.tgl_skep_bmn between '$tgl_awal' and '$tgl_akhir' and usulan.no_skep_bmn ='$no_skep'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $no_skep; ?></td>
        <td><?php echo $data['jenis_peruntukan']; ?></td>
        <td><?php echo $data['no_usulan']; ?></td>
        <td><?php echo $data['tgl_usulan']; ?></td>
        <td><a href="../upload_peruntukan/<?php echo $data['dok_usulan']; ?>"><?php echo $data['dok_usulan']; ?></a></td>
        <td><?php echo $data['tujuan_pengajuan']; ?></td>
        <td><?php echo $data['nilai_limit']; ?></td>
        <td><?php echo $data['ket_usulan']; ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
<?php } else {
?>

<?php 
// Detail Uraian Nama Barang
  if(!empty($_GET['nm_bar']) and !empty($_GET['no_skep'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th rowspan="2">No SKEP</th>
        <th rowspan="2">Usulan Peruntukan</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th rowspan="2">Berkas Dokumen</th>
        <th rowspan="2">Tujuan Pengajuan</th>
        <th rowspan="2">Nilai Limit</th>
        <th rowspan="2">Keterangan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];
  $nm_bar = $_GET['nm_bar'];

  $query_data = "SELECT DISTINCT usulan.jenis_peruntukan, usulan.no_usulan, usulan.tgl_usulan, usulan.dok_usulan, usulan.tujuan_pengajuan, tindak_lanjut.nilai_limit, usulan.ket_usulan FROM usulan INNER JOIN tindak_lanjut on usulan.no_skep_bmn = tindak_lanjut.no_skep_bmn inner join tbl_utama on usulan.no_skep_bmn = tbl_utama.no_skep_bmn where tbl_utama.nama_barang ='$nm_bar' and usulan.no_skep_bmn ='$no_skep'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $no_skep; ?></td>
        <td><?php echo $data['jenis_peruntukan']; ?></td>
        <td><?php echo $data['no_usulan']; ?></td>
        <td><?php echo $data['tgl_usulan']; ?></td>
         <td><a href="../upload_peruntukan/<?php echo $data['dok_usulan']; ?>"><?php echo $data['dok_usulan']; ?></a></td>
        <td><?php echo $data['tujuan_pengajuan']; ?></td>
        <td><?php echo $data['nilai_limit']; ?></td>
        <td><?php echo $data['ket_usulan']; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } else {
?>

<?php
//Detail Uraian Status Peruntukan
     if(!empty($_GET['status']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th rowspan="2">No SKEP</th>
        <th rowspan="2">Usulan Peruntukan</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th rowspan="2">Berkas Dokumen</th>
        <th rowspan="2">Tujuan Pengajuan</th>
        <th rowspan="2">Nilai Limit</th>
        <th rowspan="2">Keterangan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
      </tr>
    </thead>
      <tbody>
      <?php 
      
    $no_skep = $_GET['no_skep'];
    $status = $_GET['status'];

    $query_data = "SELECT DISTINCT usulan.jenis_peruntukan, usulan.no_usulan, usulan.tgl_usulan, usulan.dok_usulan, usulan.tujuan_pengajuan, tindak_lanjut.nilai_limit, usulan.ket_usulan FROM usulan INNER JOIN tindak_lanjut on usulan.no_skep_bmn = tindak_lanjut.no_skep_bmn inner join tbl_utama on usulan.no_skep_bmn = tbl_utama.no_skep_bmn where usulan.no_skep_bmn ='$no_skep'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $no_skep; ?></td>
        <td><?php echo $data['jenis_peruntukan']; ?></td>
        <td><?php echo $data['no_usulan']; ?></td>
        <td><?php echo $data['tgl_usulan']; ?></td>
         <td><a href="../upload_peruntukan/<?php echo $data['dok_usulan']; ?>"><?php echo $data['dok_usulan']; ?></a></td>
        <td><?php echo $data['tujuan_pengajuan']; ?></td>
        <td><?php echo $data['nilai_limit']; ?></td>
        <td><?php echo $data['ket_usulan']; ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
<?php }  else {
?>

<?php 
// Detail Uraian No Skep
  if(!empty($_GET['no_skep']) and empty($_GET['awal']) and empty($_GET['akhir']) and empty($_GET['nm_bar']) and empty($_GET['status'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th rowspan="2">No</th>
        <th rowspan="2">No SKEP</th>
        <th rowspan="2">Usulan Peruntukan</th>
        <th colspan="2">Dokumen Pengajuan</th>
        <th rowspan="2">Berkas Dokumen</th>
        <th rowspan="2">Tujuan Pengajuan</th>
        <th rowspan="2">Nilai Limit</th>
        <th rowspan="2">Keterangan</th>
      </tr>
      <tr>
        <td>Nomor</td>
        <td>Tanggal</td>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];

  $query_data = "SELECT DISTINCT usulan.jenis_peruntukan, usulan.no_usulan, usulan.tgl_usulan, usulan.dok_usulan, usulan.tujuan_pengajuan, tindak_lanjut.nilai_limit, usulan.ket_usulan FROM usulan INNER JOIN tindak_lanjut on usulan.no_skep_bmn = tindak_lanjut.no_skep_bmn inner join tbl_utama on usulan.no_skep_bmn = tbl_utama.no_skep_bmn where usulan.no_skep_bmn ='$no_skep'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $no_skep; ?></td>
        <td><?php echo $data['jenis_peruntukan']; ?></td>
        <td><?php echo $data['no_usulan']; ?></td>
        <td><?php echo $data['tgl_usulan']; ?></td>
         <td><a href="../upload_peruntukan/<?php echo $data['dok_usulan']; ?>"><?php echo $data['dok_usulan']; ?></a></td>
        <td><?php echo $data['tujuan_pengajuan']; ?></td>
        <td><?php echo $data['nilai_limit']; ?></td>
        <td><?php echo $data['ket_usulan']; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } 
} 
} 
}
?>






