<?php
// Detail Uraian Tanggal
  include "../../inc/koneksi.php";
  if(!empty($_GET['awal']) and !empty($_GET['akhir']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
      <thead>
        <tr>
          <th>No</th>
        <th>Nama Barang</th>
        <th>Asal Dokumen</th>
        <th>No Dokumen</th>
        <th>Tanggal Dokumen</th>
        <th>Keterangan</th>
        </tr>
      </thead>
      <tbody>
      <?php 

    $no_skep = $_GET['no_skep'];
    $tgl_awal = $_GET['awal'];
    $tgl_akhir = $_GET['akhir'];

    $query_data = "SELECT DISTINCT tbl_utama.nama_barang, dokumen_asal.asal_dokumen, dokumen_asal.no_dokumen, dokumen_asal.tgl_dokumen, dokumen_asal.keterangan_dok FROM tbl_utama INNER JOIN dokumen_asal on tbl_utama.no_skep_bmn = dokumen_asal.no_skep_bmn where dokumen_asal.tgl_dokumen between '$tgl_awal' and '$tgl_akhir'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
          <td><?php echo $nomor; ?></td>
        <td><?php echo $data['nama_barang']; ?></td>
        <td><?php echo $data['asal_dokumen']; ?></td>
        <td><?php echo $data['no_dokumen']; ?></td>
        <td><?php echo $data['tgl_dokumen']; ?></td>
        <td><?php echo $data['keterangan_dok']; ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
<?php } else {
?>

<?php 
// Detail Uraian Nama Barang
  if(!empty($_GET['nm_bar']) and !empty($_GET['no_skep'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Barang</th>
        <th>Asal Dokumen</th>
        <th>No Dokumen</th>
        <th>Tanggal Dokumen</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];
  $nm_bar = $_GET['nm_bar'];

  $query_data = "SELECT DISTINCT tbl_utama.nama_barang, dokumen_asal.asal_dokumen, dokumen_asal.no_dokumen, dokumen_asal.tgl_dokumen, dokumen_asal.keterangan_dok FROM tbl_utama INNER JOIN dokumen_asal on tbl_utama.no_skep_bmn = dokumen_asal.no_skep_bmn where tbl_utama.nama_barang = '$nm_bar'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['nama_barang']; ?></td>
        <td><?php echo $data['asal_dokumen']; ?></td>
        <td><?php echo $data['no_dokumen']; ?></td>
        <td><?php echo $data['tgl_dokumen']; ?></td>
        <td><?php echo $data['keterangan_dok']; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } else {
?>

<?php
//Detail Uraian Status Peruntukan
     if(!empty($_GET['status']) and !empty($_GET['no_skep'])){ ?> 
    <table id="example" class="table table-striped table-bordered" style="width:100%">
      <thead>
        <tr>
         <th>No</th>
        <th>Nama Barang</th>
        <th>Asal Dokumen</th>
        <th>No Dokumen</th>
        <th>Tanggal Dokumen</th>
        <th>Keterangan</th>
        </tr>
      </thead>
      <tbody>
      <?php 
      
    $no_skep = $_GET['no_skep'];
    $status = $_GET['status'];

   $query_data = "SELECT DISTINCT tbl_utama.nama_barang, dokumen_asal.asal_dokumen, dokumen_asal.no_dokumen, dokumen_asal.tgl_dokumen, dokumen_asal.keterangan_dok FROM tbl_utama INNER JOIN dokumen_asal on tbl_utama.no_skep_bmn = dokumen_asal.no_skep_bmn inner join tindak_lanjut on dokumen_asal.no_skep_bmn = tindak_lanjut.no_skep_bmn where tbl_utama.no_skep_bmn = '$no_skep'";
    $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
        $nomor = 0;
    while($data = mysqli_fetch_array($query_mysql)){
      $nomor++;
    ?>
        <tr>
          <td><?php echo $nomor; ?></td>
        <td><?php echo $data['nama_barang']; ?></td>
        <td><?php echo $data['asal_dokumen']; ?></td>
        <td><?php echo $data['no_dokumen']; ?></td>
        <td><?php echo $data['tgl_dokumen']; ?></td>
        <td><?php echo $data['keterangan_dok']; ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
<?php }  else {
?>

<?php 
// Detail Uraian No Skep
  if(!empty($_GET['no_skep']) and empty($_GET['awal']) and empty($_GET['akhir']) and empty($_GET['nm_bar']) and empty($_GET['status'])){ ?> 
  <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
      <tr>
       <th>No</th>
        <th>Nama Barang</th>
        <th>Asal Dokumen</th>
        <th>No Dokumen</th>
        <th>Tanggal Dokumen</th>
        <th>Keterangan</th>
      </tr>
    </thead>
    <tbody>
    <?php 
    
  $no_skep = $_GET['no_skep'];

  $query_data = "SELECT DISTINCT tbl_utama.nama_barang, dokumen_asal.asal_dokumen, dokumen_asal.no_dokumen, dokumen_asal.tgl_dokumen, dokumen_asal.keterangan_dok FROM tbl_utama INNER JOIN dokumen_asal on tbl_utama.no_skep_bmn = dokumen_asal.no_skep_bmn where dokumen_asal.no_skep_bmn = '$no_skep'";
  $query_mysql = mysqli_query($con, $query_data)or die(mysqli_error());
      $nomor = 0;
  while($data = mysqli_fetch_array($query_mysql)){
    $nomor++;
  ?>
      <tr>
        <td><?php echo $nomor; ?></td>
        <td><?php echo $data['nama_barang']; ?></td>
        <td><?php echo $data['asal_dokumen']; ?></td>
        <td><?php echo $data['no_dokumen']; ?></td>
        <td><?php echo $data['tgl_dokumen']; ?></td>
        <td><?php echo $data['keterangan_dok']; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
<?php } 
} 
} 
}
?>


