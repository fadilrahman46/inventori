<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi Barang yang Menjadi Milik Negara</title> <!-- CSS -->
  <link href="../assets/css/bootstrap.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../assets/fonts/css/all.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/login.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">

</head>
<style>
* {
  box-sizing: border-box;
}

body {
  background-color: #f1f1f1;
}

#regForm {
  background-color: #ffffff;
  margin: 50px auto;
  font-family: Raleway;
  padding: 40px;
  width: 70%;
  min-width: 400px;
}

h1 {
  text-align: center;  
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: block;
}

button {
  background-color: #6751b7;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}
</style>

<body>
<?php include '../inc/cek-login.php'; ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">Aplikasi Barang yang menjadi Milik Negara</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
     
      <a class="btn" style="background-color:white;color:grey;" href="index.php">Back to Home</a>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i> <?php echo $_SESSION['username'];?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="pass.php"><i class="fas fa-cog"></i> Ganti Password ..</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </ul>
      </div>
    </div>
  </nav>


<div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
    <?php 
    if(isset($_GET['alert'])){
      if($_GET['alert']=='gagaladmin'){
        ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-warning"></i> Peringatan !</h4>
          Input Gagal. Data Sudah Ada
        </div>                
        <?php
      }elseif($_GET['alert']=="berhasil"){
        ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-check"></i> Success</h4>
          Berhasil Disimpan
        </div>                
        <?php
      }elseif($_GET['alert']=="gagalkantor"){
        ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-check"></i> Peringatan !</h4>
          Input Gagal. Nama Kantor Tidak Ada
        </div>                
        <?php
      }
    }
    ?>
    <div class="card card0 border-0" style="background-color: #6751b7; margin-bottom: 10px; ">
        <div class="row d-flex">
            <div class="col-lg-6">
                <div class="card1 pb-5" style="margin-top: 50px;">
                    <div class="row px-3 justify-content-center mb-5 border-line"> <img src="../icon.png" height="270" width="300" style="border-radius: 5px"> </div>
                    <span class="row px-3 justify-content-center"><a href="data_kantor.php" class="btn" style="background-color:#28156f; color:white;" >Lihat Data Kantor</a></span>
                
                </div>
            </div>
            <div class="col-lg-6" style="margin-bottom: 50px;">               
              
                  <form id="regForm" method="POST" action="search/input-aksi.php?aksi=user">
                        <div class="tab form-group">
                        <h2>Input User</h2>
                        <label>Kode Kantor</label>
                        <p><input name="kode_kantor"></p>
                        <label>Nama Kantor</label>
                        <p><input name="nama_kantor"></p>
                        
                      </div>
                  
                      <div style="overflow:auto;">
                        <div style="float:right;">
                          <button type="button" id="prevBtn" >Back</button>
                          <button type="submit" id="nextBtn" >Submit</button>
                        </div>
                      </div>
                  </form>                               
                    
            </div>
            </div>
        </div>
        <div class="bg-blue py-4">
            <div class="row px-3"> <small class="ml-4 ml-sm-5 mb-2">Copyright &copy; 2021. All rights reserved.</small>
                <div class="social-contact ml-4 ml-sm-auto"> <span class="fa fa-facebook mr-4 text-sm"></span> <span class="fa fa-google-plus mr-4 text-sm"></span> <span class="fa fa-linkedin mr-4 text-sm"></span> <span class="fa fa-twitter mr-4 mr-sm-5 text-sm"></span> </div>
            </div>
        </div>
    </div>
</div>
  <script  src="../assets/js/form.js" type="text/javascript"></script>
  <script src="../assets/js/jquery.slim.js"></script>
  <script src="../assets/js/bootstrap.bundle.js"></script>
</body>
</html>